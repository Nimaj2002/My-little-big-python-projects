from passwordgen import password_gen
from keygen import keygen

print("Welcome to Python Password Generator")
total_letters = int(input("How many letters do you want to have in your password?:\n"))
total_symbols = int(input("How many symbols do you want to have in your password?:\n"))
total_numbers = int(input("How many numbers do you want to have in your password?:\n"))
print( password_gen( total_letters , total_symbols , total_numbers ) )

print("Welcome to Python key Generator")
total_letter = int(input("How many letters do you want to have in your password?:\n"))
print(keygen(total_letter))
        